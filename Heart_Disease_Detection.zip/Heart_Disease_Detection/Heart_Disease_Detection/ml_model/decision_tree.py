import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
import joblib
from imblearn.over_sampling import SMOTE  # لتطبيق SMOTE

# ✅ Load dataset (Make sure to replace 'your_dataset.csv' with the correct filename)
data = pd.read_csv(r".\data\cleaned_data.csv")  # 🔹 Ensure the dataset exists

# Define features and target
X = data.drop(columns=['target'])  # Features
y = data['target']  # Target (Heart Disease Risk: 0 = Low, 1 = High)

# Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# تحقق من توزيع الفئات
print("Distribution of target variable in training data:")
print(y_train.value_counts())  # طباعة التوزيع بين الفئات

# 1️⃣ إعادة توازن البيانات باستخدام SMOTE (إذا كانت البيانات غير متوازنة)
smote = SMOTE(random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)

# 2️⃣ Train Decision Tree Classifier
clf = DecisionTreeClassifier(random_state=42)
clf.fit(X_train_resampled, y_train_resampled)

# 4️⃣ Hyperparameter Tuning using GridSearchCV
param_grid = {
    'max_depth': [3, 5, 10, None],
    'min_samples_split': [2, 5, 10]
}
grid_search = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train_resampled, y_train_resampled)

best_model = grid_search.best_estimator_

# 5️⃣ Evaluate Model
y_pred = best_model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print(f"✅ Accuracy: {accuracy:.4f}")
print(f"✅ Precision: {precision:.4f}")
print(f"✅ Recall: {recall:.4f}")
print(f"✅ F1-score: {f1:.4f}")

# 6️⃣ Show Confusion Matrix
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# 7️⃣ Save Model
joblib.dump(best_model, "decision_tree_model.pkl")
print("📦 Model saved as 'decision_tree_model.pkl'!")
