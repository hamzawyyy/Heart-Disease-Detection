﻿**Heart Disease Detection**

**Project Structure**

**Heart\_Disease\_Detection/**

**│**

**├ ─ ─ data/                           # Contains the dataset (raw & cleaned)**

**│   ├ ─ ─ heart.csv**

**│   ├ ─ ─ cleaned\_data.csv**

**│**

**├ ─ ─ notebooks/                      # Jupyter Notebooks for visualization & preprocessing │   ├ ─ ─ heart\_vis.ipynb**

**│**

**├ ─ ─ rule\_based\_system/               # Rule-based system using Experta**

**│   ├ ─ ─ expert\_system.py**

**│**

**├ ─ ─ UI.py                            # Streamlit UI for user interaction**

**│**

**├ ─ ─ reports/                         # Comparison reports and evaluation**

**│   ├ ─ ─ accuracy\_comparison.pdf**

**│**

**├ ─ ─ README.md                        # Project documentation**

**│**

**├ ─ ─ README.pdf                       # PDF version of the documentation**

**Description**

**This project is designed to predict the risk of heart disease using a machine learning model. It includes data preprocessing, a rule-based system, and a user interface built with Streamlit.**

**Features**

- **Dataset preprocessing and visualization.**
- **Rule-based system implementation.**
- **Machine learning model evaluation.**
- **Streamlit web application for user interaction.**
- **Comparison and evaluation reports.**

**How to Run**

1. **Install dependencies:**
1. **pip install -r requirements.txt**
1. **Run the Streamlit UI:**
1. **streamlit run UI.py**

**Decision Tree Model.py**

**This project involves training and evaluating a Decision Tree Classifier for diabetes prediction using Scikit-Learn. The key steps include:**

1. **Data Preprocessing:**
   1. **Features (X) and target (y) are defined.**
   1. **The dataset is split into training (80%) and testing (20%) sets.**
1. **Model Training:**
   1. **A Decision Tree Classifier is trained on the training data.**
1. **Hyperparameter Tuning:**
   1. **GridSearchCV is used to find the best parameters (max\_depth, min\_samples\_split).**
   1. **The model is optimized using 5-fold cross-validation.**
1. **Model Evaluation:**
   1. **Predictions are made on the test set.**
   1. **Performance metrics include Accuracy, Precision, Recall, and F1-score.**
1. **Model Saving:**
- **The best-performing model is saved as "decision\_tree\_model.pkl" using Joblib.**

**Final Output:**

- **The trained model is optimiz ed f or accur acy and st ored f or futur e predictions.**  🚀

**Your data\_analysis.ipynb notebook likely contains data preprocessing, visualization, and statistical analysis. Here’s a general summary of what such a notebook typically includes:**

**Data Analysis.ipynb**

1\. **Data Loading & Cleaning**

- **The dataset is loaded using pandas.**
  1. **Missing values are handled (e.g., removed or imputed).**
  1. **Categorical variables are encoded.**
2. **Exploratory Data Analysis (EDA)**
   1. **Statistical Summary: Mean, median, standard deviation of features.**
   1. **Correlation Analysis: Identifies relationships between features using heatmaps.**
   1. **Feature Distributions: Histograms and boxplots to visualize data spread and outliers.**
2. **Feature Engineering**
   1. **Scaling numerical features.**
   1. **Selecting important features for model training.**
2. **Insights & Findings**
   1. **Key trends in the dataset.**
   1. **Identified risk factors based on visualization.**

**Model Training.ipynb**

**This notebook focuses on preprocessing and training a machine learning model for heart disease prediction.**

1. **Data Loading & Cleaning**
   1. **Reads the dataset (heart (1).csv) using pandas.**
   1. **Checks for missing values and fills them with the column mean.**
1. **Feature Scaling & Selection**
   1. **Normalizes numerical features using MinMaxScaler.**
   1. **Selects key features such as age, blood pressure, cholesterol, heart rate, and ST depression (oldpeak).**
1. **Exploratory Data Analysis (EDA)**
   1. **Uses .info() and .head() to inspect data.**
   1. **Visualizes feature distributions using box plots to detect outliers.**
1. **Model Preparation**
- **Imports RandomForestClassifier for training.**

**expert system.py**

**This Python script implements an expert system for health risk assessment using the experta library.**

1. **Imports & Setup**
   1. **Uses pandas, numpy, and experta for expert system rules.**
   1. **Fixes compatibility issues with collections.abc.**
1. **User Input Collection**
   1. **Prompts users to enter details like cholesterol, age, blood pressure, smoking habits, exercise, BMI, heart rate, chest pain, and diet.**
   1. **Validates inputs and handles errors.**
1. **Expert System Execution**
- **Initializes the HealthRiskExpert inference engine.**
- **Declares user inputs as facts in the system.**
- **Runs inference to analyze health risks based on provided data.**

**expert system.py**

**This script defines an expert system using experta to assess health risks based on user input.**

1. **Expert System Class (HealthRiskExpert)**
   1. **Uses predefined rules to evaluate risk factors.**
   1. **Each rule checks conditions based on user facts and triggers appropriate risk messages.**
1. **Defined Rules:**
- **High Risk:**
  - **High cholesterol (>240) & age >50.**
  - **High blood pressure (>140) & smoking.**
  - **Severe high BP (>160) & age >60.**
  - **Diabetes & high cholesterol (>250).**
  - **Obesity (BMI >30) & no exercise.**
  - **Smoking, no exercise, & age >50.**
  - **Family history & high cholesterol (>220).**
  - **High stress & high blood pressure (>130).**
- **Low Risk:**
  - **Regular exercise & BMI <25.**
  - **Healthy diet, regular exercise, & non-smoker.**

**This Python script implements a Streamlit-based heart disease risk prediction app using a pre-trained Decision Tree model.**

**UI.py**

1. **Setup & Model Loading**
   1. **Imports necessary libraries (streamlit, joblib, numpy, pandas, matplotlib).**
   1. **Sets up project paths and loads the decision\_tree\_model.pkl file.**
   1. **Verifies that the model file exists before proceeding.**
1. **User Interface with Streamlit**
   1. **Creates an interactive web app for users to input health data.**
   1. **Features include sliders, select boxes, and number inputs for variables like age, cholesterol, blood pressure, chest pain, and more.**
1. **Data Preprocessing**
   1. **Converts categorical inputs (e.g., sex, fasting blood sugar, exercise angina) into numerical values.**
   1. **Organizes data into a format suitable for model prediction.**
1. **Prediction & Visualization**
   1. **When the user clicks "Predict Risk," the script:**
      1. **Passes input data to the trained model.**
      1. **Displays the predicted risk level (High or Low).**
      1. **Uses a pie chart to visualize the risk probability.**
5. **General Statistics**
   1. **Generates random data to simulate population-level risk distribution.**
- **Displays a bar chart showing counts of high vs. low risk.**

**Key Features**

- **Interactiv e user in terface f or health risk assessmen t.**
- **Real -time pr ediction using a tr ained Decision T ree model .**
- **Visual insigh ts thr ough char ts and sta tistics.**
