﻿**Comparison and Evaluation Report**

1. **Introduction**

This report provides a comparison of di erent models used for heart disease risk prediction, evaluating their performance based on accuracy, precision, recall, and F1- score.

2. **Models Compared**
1. **Logistic Regression**
1. **Decision Tree**
1. **Random Forest**
1. **Support Vector Machine (SVM)**
1. **Neural Networks**
3. **Performance Metrics**

The evaluation metrics used for comparison are:

- **Accuracy**: Measures overall correctness.
- **Precision**: Ratio of correctly predicted positive observations to total predicted positives.
- **Recall**: Ratio of correctly predicted positives to all actual positives.
- **F1-Score**: Harmonic mean of precision and recall.

![](Aspose.Words.22d3c19a-22a2-44f5-8792-749ca559e78f.001.jpeg)

4. **Analysis and Findings**
- **Neural Networks** performed the best with the highest accuracy and F1-score.
- **Random Forest** also performed well, balancing precision and recall e ectively.
- **Logistic Regression** had good performance but slightly lower recall.
- **Decision Tree** had the lowest accuracy, indicating overfitting or lack of generalization.
- **SVM** showed stable performance but was outperformed by Random Forest and Neural Networks.
5. **Conclusion**

Neural Networks is the best model for this dataset, followed closely by Random Forest. However, if interpretability is a key factor, Logistic Regression remains a strong choice.

6. **Future Work**
- Fine-tune hyperparameters for further improvements.
- Test additional ensemble methods.
- Collect more diverse data to improve model generalization.
