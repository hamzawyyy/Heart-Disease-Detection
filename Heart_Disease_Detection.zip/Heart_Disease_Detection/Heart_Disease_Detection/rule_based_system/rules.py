import collections
import collections.abc
collections.Mapping = collections.abc.Mapping
from experta import *

# Define an Expert System Class
class HealthRiskExpert(KnowledgeEngine):
    
    @Rule(Fact(cholesterol=P(lambda x: x > 240)) & Fact(age=P(lambda x: x > 50)))
    def high_cholesterol_risk(self):
        print("⚠ High Risk: High cholesterol and age over 50!")

    @Rule(Fact(blood_pressure=P(lambda x: x > 140)) & Fact(smoking="yes"))
    def high_bp_smoking_risk(self):
        print("⚠ High Risk: High blood pressure and smoking detected!")

    @Rule(Fact(exercise="regular") & Fact(bmi=P(lambda x: x < 25)))
    def low_risk_fitness(self):
        print("✅ Low Risk: Regular exercise and healthy BMI!")

    @Rule(Fact(blood_pressure=P(lambda x: x > 160)) & Fact(age=P(lambda x: x > 60)))
    def severe_bp_risk(self):
        print("⚠ Severe Risk: Very high blood pressure in elderly!")

    @Rule(Fact(diabetes="yes") & Fact(cholesterol=P(lambda x: x > 250)))
    def diabetes_cholesterol_risk(self):
        print("⚠ High Risk: Diabetes combined with high cholesterol!")

    @Rule(Fact(bmi=P(lambda x: x > 30)) & Fact(exercise="none"))
    def obesity_risk(self):
        print("⚠ High Risk: Obesity and lack of exercise!")

    @Rule(Fact(smoking="yes") & Fact(exercise="none") & Fact(age=P(lambda x: x > 50)))
    def smoking_no_exercise_risk(self):
        print("⚠ Very High Risk: Smoking, no exercise, and age over 50!")

    @Rule(Fact(family_history="yes") & Fact(cholesterol=P(lambda x: x > 220)))
    def genetic_cholesterol_risk(self):
        print("⚠ High Risk: Family history of heart disease and high cholesterol!")

    @Rule(Fact(blood_pressure=P(lambda x: x > 130)) & Fact(stress="high"))
    def stress_hypertension_risk(self):
        print("⚠ Risk: High blood pressure due to stress!")

    @Rule(Fact(exercise="regular") & Fact(diet="healthy") & Fact(smoking="no"))
    def very_low_risk(self):
        print("✅ Very Low Risk: Healthy lifestyle detected!")
