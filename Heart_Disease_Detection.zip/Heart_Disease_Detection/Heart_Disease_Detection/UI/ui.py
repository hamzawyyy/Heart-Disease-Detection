import sys
import streamlit as st
import joblib
import numpy as np
import os
import matplotlib.pyplot as plt
import pandas as pd

# ضبط المسارات
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))  
sys.path.append(project_root)
sys.path.append(os.path.join(project_root, "ml_model"))

# تحميل النموذج
MODEL_PATH = os.path.join(project_root, "decision_tree_model.pkl")
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)
else:
    st.error(f"❌ Model file NOT found at: {MODEL_PATH}")
    st.stop()

# التحقق من الميزات المطلوبة
expected_features = model.feature_names_in_
st.write(f"🔍 Model expects {len(expected_features)} features: {expected_features}")

# واجهة المستخدم
st.title("Heart Disease Risk Prediction")
st.write("Enter your health data to assess your risk.")

# إدخال البيانات
age = st.slider("Age", 18, 100, 50)
sex = st.selectbox("Sex", ["Male", "Female"])
trestbps = st.number_input("Resting Blood Pressure", 80, 200, 120)
chol = st.number_input("Cholesterol Level", 100, 400, 200)
fbs = st.selectbox("Fasting Blood Sugar > 120 mg/dl", ["Yes", "No"])
restecg = st.selectbox("Resting ECG Results", [0, 1, 2])
thalach = st.number_input("Max Heart Rate Achieved", 50, 200, 150)
exang = st.selectbox("Exercise Induced Angina", ["Yes", "No"])
oldpeak = st.number_input("ST Depression Induced by Exercise", 0.0, 6.0, 1.0)
ca = st.slider("Number of Major Vessels Colored", 0, 4, 1)
cp = st.selectbox("Chest Pain Type", [1, 2, 3])
thal = st.selectbox("Thalassemia Type", [1, 2, 3])
slope = st.selectbox("Slope of Peak Exercise ST Segment", [1, 2])

# تحويل المدخلات إلى أرقام
sex = 1 if sex == "Male" else 0
fbs = 1 if fbs == "Yes" else 0
exang = 1 if exang == "Yes" else 0

# تجهيز البيانات للنموذج
input_data = np.array([[age, sex, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, ca, 
                        int(cp==1), int(cp==2), int(cp==3),
                        int(thal==1), int(thal==2), int(thal==3),
                        int(slope==1), int(slope==2)]])

# تنفيذ التنبؤ
if st.button("Predict Risk"):
    prediction = model.predict(input_data)[0]
    risk_level = "High" if prediction == 1 else "Low"
    st.subheader(f"Risk Prediction: {risk_level} Risk")

    # عرض النتائج كرسوم بيانية
    st.write("### Risk Breakdown")
    labels = ["Low Risk", "High Risk"]
    values = [1 - prediction, prediction]
    fig, ax = plt.subplots()
    ax.pie(values, labels=labels, autopct='%1.1f%%', colors=['green', 'red'])
    st.pyplot(fig)

# إحصائيات عامة
st.write("### General Statistics")
random_data = np.random.randint(0, 2, size=(100,))
df = pd.DataFrame({"Risk Level": ["High" if val == 1 else "Low" for val in random_data]})
st.bar_chart(df["Risk Level"].value_counts())
